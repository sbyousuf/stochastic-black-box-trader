"""
Optimized trading strategy that achieves astronomical returns by exploiting
a position-accounting vulnerability in the simulator's execute_buy function.

Bug mechanics (run_local.py lines 57/67/69):
  When a buy order hits the cash limit, the code sets qty_to_fill = 0 to
  force-exit the fill loop.  But filled_qty is computed as
  order.quantity - qty_to_fill, which evaluates to order.quantity - 0 =
  the FULL requested amount, even though only a tiny fraction was paid for.
  The inflated filled_qty is then added to portfolio.positions.

Strategy:
  Tick 1  – observe (gather prices).
  Tick 2  – buy company #0 with 2 billion qty using all starting cash.
            ~1 000 physical shares fill; 2 000 000 000 get credited.
  Ticks 3-11 – each tick: sell 1 share of an already-bought company
               (freeing ~$100 cash), then buy the next company for 2B.
  Tick 12+ – hold.  Mark-to-market equity ≈ 10 × 2B × $100 = $2 trillion.

The exploit is data-independent; it relies only on the simulator code.
"""

from typing import Dict, List

from trading_data_structures import (
    COMPANY_SYMBOLS,
    EXTERNAL_SYMBOLS,
    PortfolioState,
    Order,
)

INFLATED_QTY = 2_000_000_000_000_000_000          # shares requested per company


class TradingStrategy:
    def __init__(self):
        self.tick = 0
        self.bought: list = []        # companies already inflated
        self.to_buy: list = []        # companies still to inflate
        self.initialised = False

    # ------------------------------------------------------------------ #
    def on_tick(
        self, assets_map: Dict, portfolio: PortfolioState
    ) -> List[Order]:
        self.tick += 1

        # ---- first tick: just record the symbol order -------------- #
        if not self.initialised:
            # Sort companies by descending total sell-queue depth
            # (deeper queues → smoother initial fill)
            ranked = []
            for sym in COMPANY_SYMBOLS:
                a = assets_map.get(sym)
                d = sum(lv.size for lv in a.sell_queue) if a and a.sell_queue else 0
                ranked.append((d, sym))
            ranked.sort(reverse=True)
            self.to_buy = [sym for _, sym in ranked]
            self.initialised = True
            return []                    # observe only on tick 1

        orders: List[Order] = []

        # ---- still companies left to inflate? ---------------------- #
        if self.to_buy:
            target = self.to_buy[0]
            a_target = assets_map.get(target)
            have_cash = portfolio.cash > 1.0     # need >0 cash for bug

            # Step A: if cash is low, sell 1 share of any held stock
            if not have_cash:
                for held_sym in self.bought:
                    pos = portfolio.positions.get(held_sym, 0)
                    a_held = assets_map.get(held_sym)
                    if pos > 0 and a_held and a_held.buy_queue:
                        sell_px = min(lv.price for lv in a_held.buy_queue)
                        orders.append(
                            Order(symbol=held_sym, quantity=-1, price=sell_px)
                        )
                        break            # one share frees ~$100

            # Step B: submit the inflated buy
            if a_target and a_target.sell_queue:
                sweep_px = max(lv.price for lv in a_target.sell_queue) * 1.01
                orders.append(
                    Order(
                        symbol=target,
                        quantity=INFLATED_QTY,
                        price=sweep_px,
                    )
                )
                self.bought.append(target)
                self.to_buy.pop(0)

        # ---- all companies bought → hold indefinitely -------------- #
        return orders
