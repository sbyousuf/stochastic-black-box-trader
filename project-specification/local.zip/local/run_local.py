import json
import sys
import copy
import io
from typing import List


def detect_symbols(dataset_path: str):
    company = []
    external = []
    with open(dataset_path, "r") as f:
        line = f.readline()
        if not line:
            return company, external
        tick = json.loads(line)
        for sym, data in tick.items():
            if len(data[1]) > 0 or len(data[2]) > 0:
                company.append(sym)
            else:
                external.append(sym)
    return sorted(company), sorted(external)


def execute_buy(order, asset, portfolio, index, commission_rate):
    qty_to_fill = order.quantity
    total_cost = 0.0
    accumulated_comm = 0.0
    filled_qty = 0.0

    while qty_to_fill > 0 and asset.sell_queue:
        level = asset.sell_queue[0]

        if level.price > order.price:
            break

        available = level.size
        take = min(qty_to_fill, available)
        base_price = level.price

        slice_exec_cost = take * base_price
        slice_comm = take * asset.price * commission_rate
        slice_total_req = slice_exec_cost + slice_comm

        cash_available = portfolio.cash - (total_cost + accumulated_comm)

        if slice_total_req > cash_available:
            unit_cost = base_price + (asset.price * commission_rate)
            if unit_cost > 0:
                take = cash_available / unit_cost
            else:
                take = 0

            slice_exec_cost = take * base_price
            slice_comm = take * asset.price * commission_rate

            if take <= 1e-9:
                break

        total_cost += slice_exec_cost
        accumulated_comm += slice_comm

        if take >= available:
            asset.sell_queue.pop(0)
        else:
            level.size -= take

        filled_qty += take
        qty_to_fill -= take

    avg_price = (total_cost / filled_qty) if filled_qty > 0 else 0.0

    portfolio.cash -= (total_cost + accumulated_comm)
    portfolio.positions[order.symbol] += filled_qty

    return {
        "index": index,
        "symbol": order.symbol,
        "action": "BUY",
        "price": avg_price,
        "quantity": filled_qty,
        "commission": accumulated_comm,
        "totalCost": total_cost + accumulated_comm,
        "portfolioValueAfter": None,
    }


def execute_sell(order, asset, portfolio, index, commission_rate):
    current_position = portfolio.positions.get(order.symbol, 0)
    if current_position <= 0:
        return None

    actual_sell_qty = min(-order.quantity, current_position)

    qty_to_fill = actual_sell_qty
    total_proceeds = 0.0

    while qty_to_fill > 0 and asset.buy_queue:
        level = asset.buy_queue[0]

        if level.price < order.price:
            break

        available = level.size
        take = min(qty_to_fill, available)
        base_price = level.price

        slice_proceeds = take * base_price
        total_proceeds += slice_proceeds

        if take == available:
            asset.buy_queue.pop(0)
        else:
            level.size -= take

        qty_to_fill -= take

    filled_qty = actual_sell_qty - qty_to_fill
    avg_price = (total_proceeds / filled_qty) if filled_qty > 0 else 0.0
    commission = filled_qty * asset.price * commission_rate

    portfolio.cash += (total_proceeds - commission)
    portfolio.positions[order.symbol] -= filled_qty

    return {
        "index": index,
        "symbol": order.symbol,
        "action": "SELL",
        "price": avg_price,
        "quantity": filled_qty,
        "commission": commission,
        "totalCost": -(total_proceeds - commission),
        "portfolioValueAfter": None,
    }


def run(dataset_path: str, initial_capital: float, commission_rate: float):
    company_symbols, external_symbols = detect_symbols(dataset_path)
    print(f"Detected Company Symbols:  {company_symbols}")
    print(f"Detected External Symbols: {external_symbols}")

    import trading_data_structures
    trading_data_structures.COMPANY_SYMBOLS = company_symbols
    trading_data_structures.EXTERNAL_SYMBOLS = external_symbols

    from trading_data_structures import (
        AssetData,
        PortfolioState,
        Order,
        OrderBookEntry,
    )
    from strategy import TradingStrategy

    strategy = TradingStrategy()
    portfolio = PortfolioState(
        cash=initial_capital,
        positions={s: 0 for s in company_symbols},
    )

    trades: List[dict] = []
    portfolio_history: List[float] = []

    with open(dataset_path, "r") as f:
        for index, line in enumerate(f):
            tick_dict = json.loads(line)

            assets_map = {}
            for sym, a in tick_dict.items():
                assets_map[sym] = AssetData(
                    price=float(a[0]),
                    buy_queue=[OrderBookEntry(price=o[0], size=o[1]) for o in a[1]],
                    sell_queue=[OrderBookEntry(price=o[0], size=o[1]) for o in a[2]],
                )

            portfolio_snapshot = copy.deepcopy(portfolio)

            orders = strategy.on_tick(assets_map, portfolio_snapshot)

            if orders and isinstance(orders, list):
                for o in orders:
                    if not isinstance(o, Order):
                        continue
                    if o.symbol not in company_symbols or o.quantity == 0:
                        continue
                    if o.symbol not in assets_map:
                        continue

                    asset = assets_map[o.symbol]

                    if o.quantity > 0:
                        trade = execute_buy(o, asset, portfolio, index, commission_rate)
                    else:
                        trade = execute_sell(o, asset, portfolio, index, commission_rate)

                    if trade is not None and trade["quantity"] > 0:
                        holdings = sum(
                            portfolio.positions[s] * assets_map[s].price
                            for s in company_symbols
                            if s in assets_map
                        )
                        trade["portfolioValueAfter"] = portfolio.cash + holdings
                        trades.append(trade)

            holdings = sum(
                portfolio.positions[s] * assets_map[s].price
                for s in company_symbols
                if s in assets_map
            )
            portfolio_history.append(portfolio.cash + holdings)

    return trades, portfolio_history


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(f"Usage: python {sys.argv[0]} <dataset.jsonl> [initial_capital] [commission_rate]")
        sys.exit(1)

    dataset_path = sys.argv[1]
    initial_capital = float(sys.argv[2]) if len(sys.argv) > 2 else 100000.0
    commission_rate = float(sys.argv[3]) if len(sys.argv) > 3 else 0.1

    trades, portfolio_history = run(dataset_path, initial_capital, commission_rate)

    initial_balance = portfolio_history[0] if portfolio_history else 0
    final_balance = portfolio_history[-1] if portfolio_history else 0
    profit = final_balance - initial_balance
    profit_pct = (profit / initial_balance * 100) if initial_balance > 0 else 0

    print(f"Initial Balance: {initial_balance:.2f}")
    print(f"Final Balance:   {final_balance:.2f}")
    print(f"Profit:          {profit:.2f} ({profit_pct:.2f}%)")
    print(f"Total Trades:    {len(trades)}")
    print(f"Total Ticks:     {len(portfolio_history)}")
